# Knowix como aplicativo

Os atalhos nativos usam a tela publicada do Knowix dentro de uma janela própria. Assim, não precisam abrir uma janela do Google Chrome, mas precisam de internet. As pesquisas, vídeos e respostas continuam sendo fornecidos pelo serviço online.

## Windows

1. Instale Python pelo site oficial, caso ainda não tenha.
2. Dê dois cliques em `windows/GERAR-APP.bat`.
3. Ao terminar, encontre `windows/dist/Knowix.exe`.

O Windows pode pedir a instalação do Microsoft Edge WebView2 Runtime se ainda não estiver disponível no computador. Isso não é o Google Chrome.

## Android

O projeto Android está em `android/`. O GitHub Actions gera um APK de teste na nuvem depois que o projeto é enviado ao repositório. As instruções estão em `android/README.md`.

## Limites desta versão

- É necessário estar conectado à internet.
- O aplicativo não é um navegador geral nem funciona sem servidor; é o Knowix em uma janela de aplicativo.
- O APK gerado pelo fluxo de teste ainda não é assinado para publicação na Google Play.
