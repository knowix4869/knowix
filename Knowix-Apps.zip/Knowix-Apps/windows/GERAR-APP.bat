@echo off
setlocal
cd /d "%~dp0"

echo Instalando ferramentas de montagem do Knowix...
py -m pip install --upgrade -r requirements-build.txt
if errorlevel 1 goto erro

echo Criando o aplicativo para Windows...
py -m PyInstaller --noconfirm --clean --onefile --windowed --name Knowix knowix_desktop.py
if errorlevel 1 goto erro

echo.
echo Pronto! O aplicativo esta em: %~dp0dist\Knowix.exe
start "" "%~dp0dist"
pause
exit /b 0

:erro
echo.
echo Nao foi possivel montar o aplicativo. Confira se o Python esta instalado e se ha internet.
pause
exit /b 1
