package com.knowix.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.ClipData;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import androidx.core.content.FileProvider;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import org.json.JSONException;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final String START_URL = "https://knowix4869.github.io/knowix/";
    private static final int AUDIO_PERMISSION_REQUEST = 47;
    private static final int CAMERA_PERMISSION_REQUEST = 48;
    private static final int FILE_CHOOSER_REQUEST = 49;
    private WebView webView;
    private ProgressBar progress;
    private SpeechRecognizer speechRecognizer;
    private JavaScriptReplyProxy pendingVoiceReply;
    private JavaScriptReplyProxy activeVoiceReply;
    private String pendingVoiceLanguage = "pt-BR";
    private ValueCallback<Uri[]> pendingFileCallback;
    private Uri pendingCameraUri;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(244, 247, 252));
        getWindow().setNavigationBarColor(Color.rgb(244, 247, 252));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(244, 247, 252));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(8), dp(16), dp(8));
        bar.setBackgroundColor(Color.WHITE);

        TextView brand = new TextView(this);
        brand.setText("⌕  Knowix");
        brand.setTextColor(Color.rgb(20, 33, 61));
        brand.setTextSize(21);
        brand.setTypeface(null, 1);
        bar.addView(brand, new LinearLayout.LayoutParams(0, dp(44), 1));

        TextView refresh = new TextView(this);
        refresh.setText("↻");
        refresh.setTextSize(26);
        refresh.setTextColor(Color.rgb(36, 107, 254));
        refresh.setGravity(Gravity.CENTER);
        refresh.setContentDescription("Atualizar Knowix");
        refresh.setOnClickListener(v -> webView.reload());
        bar.addView(refresh, new LinearLayout.LayoutParams(dp(48), dp(44)));
        page.addView(bar);

        FrameLayout content = new FrameLayout(this);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setGeolocationEnabled(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!request.isForMainFrame()) return false;
                if (isKnowixOrigin(uri)) return false;

                // Só abre um link externo HTTPS após toque explícito da pessoa.
                // Redirecionamentos automáticos e esquemas como intent:, file: e javascript: são bloqueados.
                if (request.hasGesture() && "https".equalsIgnoreCase(uri.getScheme())
                        && uri.getHost() != null) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        // Se nenhum navegador lidar com o link, mantenha-o bloqueado no app.
                    }
                }
                return true;
            }

        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                          android.os.Message resultMsg) {
                return false;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                request.deny();
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (!isKnowixOrigin(Uri.parse(view.getUrl() == null ? "" : view.getUrl()))) {
                    callback.onReceiveValue(null);
                    return true;
                }
                cancelarSeletorAnterior();
                pendingFileCallback = callback;
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Adicionar imagem")
                        .setItems(new String[]{"Tirar uma foto", "Escolher na galeria"}, (dialog, item) -> {
                            if (item == 0) solicitarPermissaoCamera();
                            else abrirGaleria();
                        })
                        .setOnCancelListener(dialog -> finalizarSeletor(null))
                        .show();
                return true;
            }
        });
        configurarPesquisaPorVoz();
        content.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(36, 107, 254)));
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP);
        content.addView(progress, progressParams);
        page.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);

        if (state == null) webView.loadUrl(START_URL);
        else webView.restoreState(state);
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        webView.saveState(state);
        super.onSaveInstanceState(state);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                abrirCamera();
            } else {
                finalizarSeletor(null);
                android.widget.Toast.makeText(this,
                        "Permita o acesso à câmera para tirar uma foto. Você ainda pode escolher uma imagem na galeria.",
                        android.widget.Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode != AUDIO_PERMISSION_REQUEST || pendingVoiceReply == null) return;

        JavaScriptReplyProxy reply = pendingVoiceReply;
        String language = pendingVoiceLanguage;
        pendingVoiceReply = null;
        if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            iniciarReconhecimento(reply, language);
        } else {
            enviarRespostaVoz(reply, "error", "", "permission");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST) return;
        Uri selected = null;
        if (resultCode == RESULT_OK) {
            if (pendingCameraUri != null) {
                selected = pendingCameraUri;
            } else if (data != null && data.getClipData() != null
                    && data.getClipData().getItemCount() > 0) {
                selected = data.getClipData().getItemAt(0).getUri();
            } else if (data != null) {
                selected = data.getData();
            }
        }
        if (selected != null && "content".equalsIgnoreCase(selected.getScheme())) {
            finalizarSeletor(new Uri[]{selected});
        } else {
            finalizarSeletor(null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        encerrarReconhecimento(false);
        finalizarSeletor(null);
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void cancelarSeletorAnterior() {
        if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
        pendingFileCallback = null;
        pendingCameraUri = null;
    }

    private void finalizarSeletor(Uri[] resultado) {
        ValueCallback<Uri[]> callback = pendingFileCallback;
        pendingFileCallback = null;
        pendingCameraUri = null;
        if (callback != null) callback.onReceiveValue(resultado);
    }

    private void solicitarPermissaoCamera() {
        if (checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            abrirCamera();
        } else {
            requestPermissions(new String[]{android.Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
        }
    }

    private void abrirGaleria() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        try {
            startActivityForResult(Intent.createChooser(intent, "Escolher imagem"), FILE_CHOOSER_REQUEST);
        } catch (ActivityNotFoundException erro) {
            finalizarSeletor(null);
            android.widget.Toast.makeText(this, "Não foi possível abrir a galeria.",
                    android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void abrirCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) == null) {
            finalizarSeletor(null);
            android.widget.Toast.makeText(this, "Nenhuma câmera compatível foi encontrada.",
                    android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            File imageDirectory = new File(getCacheDir(), "images");
            if (!imageDirectory.exists() && !imageDirectory.mkdirs()) {
                throw new java.io.IOException("Não foi possível criar o diretório temporário.");
            }
            File image = File.createTempFile("knowix-photo-", ".jpg", imageDirectory);
            pendingCameraUri = FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider", image);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            intent.setClipData(ClipData.newUri(getContentResolver(), "Foto Knowix", pendingCameraUri));
            startActivityForResult(intent, FILE_CHOOSER_REQUEST);
        } catch (Exception erro) {
            finalizarSeletor(null);
            android.widget.Toast.makeText(this, "Não foi possível iniciar a câmera.",
                    android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isKnowixOrigin(Uri uri) {
        if (!"https".equalsIgnoreCase(uri.getScheme())) return false;
        String host = uri.getHost();
        return "knowix4869.github.io".equalsIgnoreCase(host)
                || "knowix4869-knowix.streamlit.app".equalsIgnoreCase(host);
    }

    private void configurarPesquisaPorVoz() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return;
        WebViewCompat.addWebMessageListener(
                webView,
                "KnowixAndroidVoice",
                Collections.singleton("https://knowix4869-knowix.streamlit.app"),
                (view, message, sourceOrigin, isMainFrame, replyProxy) -> {
                    if (!isKnowixVoiceOrigin(sourceOrigin)
                            || message.getType() != WebMessageCompat.TYPE_STRING) return;
                    try {
                        JSONObject command = new JSONObject(message.getData());
                        if ("start".equals(command.optString("type"))) {
                            pendingVoiceLanguage = command.optString("language", "pt-BR");
                            solicitarReconhecimento(replyProxy, pendingVoiceLanguage);
                        } else if ("cancel".equals(command.optString("type"))) {
                            encerrarReconhecimento(true);
                            enviarRespostaVoz(replyProxy, "stopped", "", "");
                        }
                    } catch (JSONException ignored) {
                        enviarRespostaVoz(replyProxy, "error", "", "error");
                    }
                }
        );
    }

    private boolean isKnowixVoiceOrigin(Uri origin) {
        return "https".equalsIgnoreCase(origin.getScheme())
                && "knowix4869-knowix.streamlit.app".equalsIgnoreCase(origin.getHost());
    }

    private void solicitarReconhecimento(JavaScriptReplyProxy reply, String language) {
        if (pendingVoiceReply != null || speechRecognizer != null) {
            enviarRespostaVoz(reply, "error", "", "error");
            return;
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            iniciarReconhecimento(reply, language);
            return;
        }
        pendingVoiceReply = reply;
        pendingVoiceLanguage = language;
        requestPermissions(
                new String[]{android.Manifest.permission.RECORD_AUDIO},
                AUDIO_PERMISSION_REQUEST
        );
    }

    private void iniciarReconhecimento(JavaScriptReplyProxy reply, String language) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            enviarRespostaVoz(reply, "error", "", "unavailable");
            return;
        }

        activeVoiceReply = reply;
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                enviarRespostaVoz(activeVoiceReply, "listening", "", "");
            }
            @Override public void onBeginningOfSpeech() { }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { }
            @Override public void onError(int error) {
                JavaScriptReplyProxy replyAtual = activeVoiceReply;
                activeVoiceReply = null;
                destruirReconhecedor();
                String tipoErro = error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS
                        ? "permission" : "error";
                enviarRespostaVoz(replyAtual, "error", "", tipoErro);
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> reconhecidos = results == null ? null
                        : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String texto = reconhecidos == null || reconhecidos.isEmpty()
                        ? "" : reconhecidos.get(0).trim();
                JavaScriptReplyProxy replyAtual = activeVoiceReply;
                activeVoiceReply = null;
                destruirReconhecedor();
                if (texto.isEmpty()) enviarRespostaVoz(replyAtual, "error", "", "error");
                else enviarRespostaVoz(replyAtual, "result", texto, "");
            }
            @Override public void onPartialResults(Bundle partialResults) { }
            @Override public void onEvent(int eventType, Bundle params) { }
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language);
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try {
            speechRecognizer.startListening(intent);
        } catch (RuntimeException erro) {
            activeVoiceReply = null;
            destruirReconhecedor();
            enviarRespostaVoz(reply, "error", "", "unavailable");
        }
    }

    private void encerrarReconhecimento(boolean notificar) {
        JavaScriptReplyProxy reply = activeVoiceReply;
        activeVoiceReply = null;
        SpeechRecognizer atual = speechRecognizer;
        speechRecognizer = null;
        if (atual != null) {
            atual.cancel();
            atual.destroy();
        }
        if (notificar) enviarRespostaVoz(reply, "stopped", "", "");
    }

    private void destruirReconhecedor() {
        SpeechRecognizer atual = speechRecognizer;
        speechRecognizer = null;
        if (atual != null) atual.destroy();
    }

    private void enviarRespostaVoz(JavaScriptReplyProxy reply, String type, String transcript, String error) {
        if (reply == null) return;
        try {
            JSONObject resposta = new JSONObject();
            resposta.put("type", type);
            resposta.put("transcript", transcript);
            resposta.put("id", java.util.UUID.randomUUID().toString());
            resposta.put("error", error);
            reply.postMessage(resposta.toString());
        } catch (JSONException | IllegalStateException ignored) {
            // A página pode ter sido fechada antes da resposta do reconhecimento.
        }
    }
}
