# Knowix para Android

Este projeto cria um app Android com uma janela própria e WebView do sistema. Ele não abre o Chrome, mas precisa de internet: as pesquisas e o conteúdo do Knowix continuam hospedados no serviço online para receber correções sem reinstalar o app.

## Gerar APK

O GitHub Actions monta automaticamente um APK de teste quando os arquivos desta pasta são enviados ao repositório. Na aba **Actions**, abra a execução `Build Knowix Android`, espere ficar verde e baixe o artefato `Knowix-Android-debug`. O arquivo `app-debug.apk` pode ser instalado para testes no Android.

Este APK de teste não é uma versão assinada para publicação na Play Store. Uma versão pública exige assinatura de lançamento e os dados de publicação do responsável pelo app.
