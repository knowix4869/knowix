"""Aplicativo de janela própria do Knowix para Windows."""

from __future__ import annotations

import webview


KNOWIX_URL = "https://knowix4869.github.io/knowix/"


def main() -> None:
    webview.create_window(
        "Knowix",
        KNOWIX_URL,
        width=1180,
        height=820,
        min_size=(360, 560),
        background_color="#f4f7fc",
        text_select=True,
    )
    webview.start(debug=False)


if __name__ == "__main__":
    main()
