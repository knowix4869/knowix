# Knowix para Android

Este projeto cria um app Android com uma janela própria e WebView do sistema. Ele não abre o Chrome, mas precisa de internet: as pesquisas e o conteúdo do Knowix continuam hospedados no serviço online para receber correções sem reinstalar o app.

## Gerar APK

O GitHub Actions monta automaticamente um APK de teste quando os arquivos desta pasta são enviados ao repositório. Na aba **Actions**, abra a execução `Build Knowix Android`, espere ficar verde e baixe o artefato `Knowix-Android-debug`. O arquivo `app-debug.apk` pode ser instalado para testes no Android.

Este APK de teste não é uma versão assinada para publicação na Play Store. Uma versão pública exige assinatura de lançamento e os dados de publicação do responsável pelo app.

## Tema claro e escuro

O tema **Sistema** acompanha a configuração claro/escuro do Android. As opções manuais **Claro** e **Escuro** nas configurações do Knowix também ajustam a moldura nativa do aplicativo.

## Pesquisa por voz e privacidade

Ao tocar em **Pesquisar por voz**, o Android pede permissão para usar o microfone. O app usa o serviço de reconhecimento de fala configurado no dispositivo; conforme esse serviço, o áudio pode ser processado localmente ou enviado para reconhecimento. O Knowix recebe o texto reconhecido e não inicia a busca até a pessoa tocar em **Pesquisar**.

## Fotos no Android

Quando uma tela do Knowix abrir um campo para enviar imagem, o seletor nativo oferece **Tirar uma foto** ou **Escolher na galeria**. A permissão de câmera só é solicitada se a pessoa escolher tirar foto; a galeria usa o seletor do Android e não pede acesso geral às fotos. A captura é gravada temporariamente no cache privado do app e compartilhada com o seletor por uma URI concedida apenas para essa operação. A disponibilidade do envio depende da funcionalidade de imagem estar ativa no site.
